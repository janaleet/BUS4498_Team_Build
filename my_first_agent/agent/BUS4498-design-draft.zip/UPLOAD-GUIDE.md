# DRAFT — not ready for submission

1. Extract this ZIP. Open your existing BUS4498_Team_Build repository.
2. Keep the charter at its existing path: README.md. Do not replace the repository-root README unless that is deliberately your charter location.
3. Upload workflow-of-tasks.md and task-summary.md into our_team_agent/agent/, and task files into its task-specs/ folder.
4. Preview the Mermaid diagram and click every task-summary link. Remove prompts and check IDs and names.
5. Commit the reviewed files with a meaningful message.
6. Use the automation worksheet to complete your course worksheet; submit the worksheet file and repository URL as required in Canvas.

- Workflow · Completed charter URL
- T4 · 1 fields/checks remain: tool input must match a named input
- T7 · 6 fields/checks remain: Next task or recipient, nonnegative retry limit, nonnegative retry limit
- T5 · 1 fields/checks remain: tool input must match a named input
- our_team_agent/agent/workflow-of-tasks.md contains unfinished fields.
- our_team_agent/agent/task-specs/revise-proposal-packet.md contains unfinished fields.
