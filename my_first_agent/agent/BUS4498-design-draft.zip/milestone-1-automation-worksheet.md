# Team Automation Level Worksheet

BUS 4498 | Team Build Milestone 1

- **Team name:** JEvents
- **Date:** 2026-09-25
- **Team members:** Janalee Taguiam, Jackson Lucas

| Task ID | Task name | Automation level | Reason |
| --- | --- | --- | --- |
| T1 | Review supplied event details | L2 | AI will interpret the guest count, event type, date, and time, but the steps and their output are fixed. |
| T3 | Identify event setup needs | L2 | AI will infer chairs, tables, AV, and space needs and spot unresolved questions from the interpretation of the event details, but the next steps are fixed. |
| T4 | Prepare template proposal | L1 | Filling out information from the documented setup is a predictable task that rules can handle. |
| T6 | Human-review proposal packet | L0 | A human will judge the proposal packet. |
| T7 | Revise proposal packet | L3 | Each review comment decides the next permitted subtask, depending on the correction. |
| T2 | Prepare clarification request | L2 | AI writes a focused request from the list of missing details, and the task always ends at the same handoff. |
| T5 | Prepare tailored proposal | L2 | AI generates custom proposal content when the template doesn't fit, but this happens in a predefined step that always goes on to human review. |
